function showSuccessPopup() {
    Swal.fire({
      title: "Thank You!",
      text: "Thank you for contacting us. We will get back to you soon!",
      icon: "success",
      confirmButtonText: "OK",
      customClass: {
        popup: "animated tada"
      }
    });
  }
  
  function showErrorPopup(errors) {
    Swal.fire({
      title: "Form Errors",
      html: errors.join("<br>"),
      icon: "error",
      confirmButtonText: "OK"
    });
  }
  
  function setupContactForm() {
    const form = document.getElementById("contactForm");
    if (form) {
      form.addEventListener("submit", function (e) {
        e.preventDefault();
  
        const formData = new FormData(form);
  
        fetch(form.action, {
          method: "POST",
          body: formData
        })
          .then((response) => response.text())
          .then((data) => {
            // The PHP redirect will handle the success popup
            form.reset();
          })
          .catch((error) => {
            Swal.fire({
              title: "Error!",
              text: "There was a problem submitting your form.",
              icon: "error"
            });
          });
      });
    }
  }
  
  document.addEventListener("DOMContentLoaded", function () {
    setupContactForm();
  
    if (typeof formSubmitted !== "undefined" && formSubmitted) {
      showSuccessPopup();
    }
  
    if (typeof formErrors !== "undefined" && formErrors.length > 0) {
      showErrorPopup(formErrors);
    }
  });
  
  function openNav() {
    document.getElementById("mySidenav").style.width = "100%";
  }
  
  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
  }
  